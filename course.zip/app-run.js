import app from "./app.js";

Deno.serve(app.fetch);
